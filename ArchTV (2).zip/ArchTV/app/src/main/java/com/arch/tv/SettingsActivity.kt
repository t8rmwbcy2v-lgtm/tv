package com.arch.tv

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.security.SecureRandom

/** One line in the settings. step = what left/right do (null = nothing special). */
class Row(
    val title: String,
    val desc: String? = null,
    val value: () -> String,
    val step: ((Int) -> Unit)? = null,
    val onClick: () -> Unit
)

class Category(val emoji: String, val name: String, val rows: List<Row>)

class SettingsActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var cats: List<Category>
    private lateinit var catAdapter: CategoryAdapter
    private lateinit var rowAdapter: RowAdapter
    private lateinit var catList: RecyclerView
    private lateinit var list: RecyclerView
    private lateinit var catTitle: TextView
    private var selected = 0
    private var server: UploadServer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        prefs = Prefs(this)

        catList = findViewById(R.id.cats)
        list = findViewById(R.id.list)
        catTitle = findViewById(R.id.catTitle)

        cats = buildCategories()
        catAdapter = CategoryAdapter(cats) { select(it) }
        rowAdapter = RowAdapter(cats[0].rows)

        catList.layoutManager = LinearLayoutManager(this)
        catList.adapter = catAdapter
        catList.itemAnimator = null
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = rowAdapter
        list.itemAnimator = null
        catTitle.text = cats[0].name

        GlassBackdrop.setStrength(when (prefs.glass) { 0 -> 0f; 1 -> 0.6f; else -> 1f })
        window.decorView.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            GlassBackdrop.setWindow(r - l, b - t)
        }
        loadBackground()
        catList.postDelayed({ catList.getChildAt(0)?.requestFocus() }, 150)
    }

    override fun onResume() {
        super.onResume()
        rowAdapter.notifyDataSetChanged() // e.g. back from the Accessibility screen
    }

    override fun onDestroy() {
        server?.stop()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (list.hasFocus()) {
            catList.findViewHolderForAdapterPosition(selected)?.itemView?.requestFocus()
        } else {
            finish()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        rowAdapter.notifyDataSetChanged()
    }

    private fun select(i: Int) {
        if (i == selected || i !in cats.indices) return
        val old = selected
        selected = i
        catAdapter.selected = i
        catAdapter.notifyItemChanged(old)
        catAdapter.notifyItemChanged(i)
        catTitle.text = cats[i].name
        rowAdapter.setRows(cats[i].rows)
    }

    /** The settings screen sits on the same photo as the home screen, so the glass has something to blur. */
    private fun loadBackground() {
        val path = prefs.lastBg ?: return
        if (!File(path).exists()) return
        val bg = findViewById<ImageView>(R.id.bg)
        Thread {
            val bmp = ImageLoader.decodeFile(path, 1280)
            runOnUiThread {
                if (bmp != null && !isDestroyed) {
                    bg.setImageBitmap(bmp)
                    GlassBackdrop.setBase(bmp)
                }
            }
        }.start()
    }

    // ---------- the settings themselves ----------

    private fun toggle(
        title: String,
        desc: String?,
        get: () -> Boolean,
        set: (Boolean) -> Unit,
        on: String = "On",
        off: String = "Off"
    ) = Row(title, desc, value = { if (get()) on else off }) { set(!get()) }

    private fun buildCategories(): List<Category> {
        val intervalMax = Prefs.INTERVAL_LABELS.size - 1
        val photos = Category(
            "\uD83D\uDDBC\uFE0F", "Photos", listOf(
                toggle("Background", "Photo slideshow, or a plain colour",
                    { prefs.natureBg }, { prefs.natureBg = it }, "Photos", "Solid colour"),
                toggle("Scenic photos", "Daily pictures from around the world",
                    { prefs.srcBing }, { prefs.srcBing = it }),
                toggle("Space photos", "Astronomy pictures from NASA",
                    { prefs.srcSpace }, { prefs.srcSpace = it }),
                Row("My photos", "Photos you've added from your phone or laptop",
                    value = { if (!prefs.srcMine) "Off" else "On  \u00B7  ${PhotoStore.list(this).size} photos" }
                ) { prefs.srcMine = !prefs.srcMine },
                Row("Add my photos", "Opens a page you can use from any device on your Wi-Fi",
                    value = { "Start" }
                ) { showReceiveDialog() },
                Row("Remove my photos", null, value = { "${PhotoStore.list(this).size} photos" }) {
                    showRemoveDialog()
                },
                Row("Change photo every", null,
                    value = { Prefs.INTERVAL_LABELS[prefs.intervalIdx] },
                    step = { d -> prefs.intervalIdx = (prefs.intervalIdx + d).coerceIn(0, intervalMax) }
                ) { prefs.intervalIdx = (prefs.intervalIdx + 1) % Prefs.INTERVAL_LABELS.size },
                Row("Photo dimming", "Darkens the picture so text is easier to read",
                    value = { "${prefs.dim}%" },
                    step = { d -> prefs.dim = (prefs.dim + d * 10).coerceIn(0, 70) }
                ) { prefs.dim = if (prefs.dim >= 70) 0 else prefs.dim + 10 }
            )
        )

        val look = Category(
            "\u2728", "Look", listOf(
                Row("Glass effect", "Frosted, see-through panels",
                    value = { arrayOf("Off", "Light", "Full")[prefs.glass] },
                    step = { d -> prefs.glass = (prefs.glass + d).coerceIn(0, 2) }
                ) { prefs.glass = (prefs.glass + 1) % 3 },
                Row("Icon size", null,
                    value = { arrayOf("Small", "Medium", "Large")[prefs.iconSize.coerceIn(0, 2)] },
                    step = { d -> prefs.iconSize = (prefs.iconSize + d).coerceIn(0, 2) }
                ) { prefs.iconSize = (prefs.iconSize + 1) % 3 },
                toggle("App names", null,
                    { prefs.labelsOnFocus }, { prefs.labelsOnFocus = it }, "Only when selected", "Always shown"),
                toggle("Program backdrop", "Show the picture behind a Continue playing card",
                    { prefs.backdrop }, { prefs.backdrop = it }),
                toggle("Clock", null, { prefs.clock24 }, { prefs.clock24 = it }, "24-hour", "12-hour"),
                toggle("Show date", null, { prefs.showDate }, { prefs.showDate = it })
            )
        )

        val home = Category(
            "\uD83C\uDFE0", "Home", listOf(
                Row("Continue playing", "Shows and films you can pick back up",
                    value = {
                        when {
                            !prefs.continueOn -> "Off"
                            ContinueRepo.hasPermission(this) -> "On"
                            else -> "Needs permission"
                        }
                    }
                ) {
                    if (prefs.continueOn && ContinueRepo.hasPermission(this)) {
                        prefs.continueOn = false
                    } else {
                        prefs.continueOn = true
                        if (!ContinueRepo.hasPermission(this)) {
                            requestPermissions(arrayOf(ContinueRepo.PERMISSION), 43)
                        }
                    }
                },
                toggle("Fix messy titles",
                    "Turns \"Show - S1, E1\" into a clean title plus \"Season 1, Episode 1\"",
                    { prefs.fixTitles }, { prefs.fixTitles = it }),
                Row("Hidden Continue items", "Select to bring them all back",
                    value = { "${prefs.hiddenContinue.size} hidden" }
                ) { prefs.hiddenContinue = emptySet() },
                toggle("App order", null,
                    { prefs.newestFirst }, { prefs.newestFirst = it }, "Newest first", "A to Z"),
                Row("Hidden apps", "Apps hidden from the dock", value = { "${prefs.hidden.size} hidden" }) {
                    showHiddenDialog()
                }
            )
        )

        val weather = Category(
            "\u2601\uFE0F", "Weather", listOf(
                toggle("Weather widget", null, { prefs.weatherOn }, { prefs.weatherOn = it }),
                toggle("Temperature unit", null,
                    { prefs.fahrenheit }, { prefs.fahrenheit = it }, "Fahrenheit (\u00B0F)", "Celsius (\u00B0C)"),
                Row("Location", "Found from your internet connection. Select to look it up again.",
                    value = { prefs.locCity?.takeIf { it.isNotEmpty() } ?: "Not found yet" }
                ) {
                    prefs.locTime = 0L
                    Toast.makeText(this, "Location will refresh on the home screen", Toast.LENGTH_SHORT).show()
                }
            )
        )

        val system = Category(
            "\u2699\uFE0F", "System", listOf(
                Row("Home button override", "Makes the remote's Home button open Arch TV",
                    value = {
                        when {
                            !prefs.homeOverride -> "Off"
                            serviceEnabled() -> "On"
                            else -> "Needs permission"
                        }
                    }
                ) {
                    if (prefs.homeOverride && serviceEnabled()) {
                        prefs.homeOverride = false
                    } else {
                        prefs.homeOverride = true
                        if (!serviceEnabled()) showAccessibilityHelp()
                    }
                },
                Row("System settings", null, value = { "Open" }) {
                    startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                },
                Row("Version", null, value = {
                    try {
                        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
                    } catch (e: Exception) {
                        ""
                    }
                }) {}
            )
        )
        return listOf(photos, look, home, weather, system)
    }

    // ---------- dialogs ----------

    private fun dialog() = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun serviceEnabled(): Boolean {
        val me = ComponentName(this, HomeKeyService::class.java)
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    private fun showAccessibilityHelp() {
        dialog()
            .setTitle("Turn on Home button override")
            .setMessage(
                "Google TV sends the Home button to Google's launcher. To catch it, switch Arch TV on " +
                    "in Accessibility.\n\n" +
                    "Settings > Accessibility > Arch TV > On\n\n" +
                    "If the switch is greyed out, go to Settings > Apps > See all apps > Arch TV, open " +
                    "the menu and choose \"Allow restricted settings\", then try again.\n\n" +
                    "To undo it any time, switch Arch TV off in the same place."
            )
            .setPositiveButton("Open Accessibility") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun showHiddenDialog() {
        val apps = AppRepo.queryAll(this).sortedBy { it.label.lowercase() }
        val hidden = prefs.hidden.toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].pkg in hidden }
        dialog()
            .setTitle("Tick the apps to hide from the dock")
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, isChecked ->
                if (isChecked) hidden.add(apps[i].pkg) else hidden.remove(apps[i].pkg)
            }
            .setPositiveButton("Done") { _, _ ->
                prefs.hidden = hidden
                rowAdapter.notifyDataSetChanged()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Starts a tiny web page on the TV; photos dropped on it from a phone or laptop join the slideshow. */
    private fun showReceiveDialog() {
        server?.stop()
        val pin = (1000 + SecureRandom().nextInt(9000)).toString()
        val s = UploadServer(PhotoStore.dir(this), pin, PhotoStore.EXT) {
            runOnUiThread { rowAdapter.notifyDataSetChanged() }
        }
        val port = s.start()
        val ip = NetUtil.localIp()
        if (port < 0 || ip == null) {
            s.stop()
            Toast.makeText(this, "Couldn't start. Is the Chromecast connected to Wi-Fi?", Toast.LENGTH_LONG).show()
            return
        }
        server = s
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        dialog()
            .setTitle("Add your photos")
            .setMessage(
                "On your phone or laptop (same Wi-Fi), open:\n\nhttp://$ip:$port\n\nThen enter the PIN:  $pin\n\n" +
                    "Drop photos on the page. They join the slideshow next time the home screen opens."
            )
            .setPositiveButton("Done", null)
            .setOnDismissListener {
                s.stop()
                if (server === s) server = null
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                rowAdapter.notifyDataSetChanged()
            }
            .show()
    }

    private fun showRemoveDialog() {
        val files = PhotoStore.list(this)
        if (files.isEmpty()) {
            Toast.makeText(this, "You haven't added any photos yet", Toast.LENGTH_SHORT).show()
            return
        }
        val checked = BooleanArray(files.size)
        dialog()
            .setTitle("Tick the photos to delete")
            .setMultiChoiceItems(files.map { it.name }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Delete ticked") { _, _ ->
                files.forEachIndexed { i, f -> if (checked[i]) f.delete() }
                rowAdapter.notifyDataSetChanged()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

class CategoryAdapter(
    private val cats: List<Category>,
    private val onSelect: (Int) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    var selected = 0

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val label: TextView = view.findViewById(R.id.catLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_category, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = cats[position]
        holder.label.text = c.emoji + "   " + c.name
        holder.itemView.isSelected = position == selected
        // moving onto a category shows its settings straight away
        holder.itemView.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) onSelect(holder.bindingAdapterPosition)
        }
        holder.itemView.setOnClickListener { onSelect(holder.bindingAdapterPosition) }
    }

    override fun getItemCount() = cats.size
}

class RowAdapter(private var rows: List<Row>) : RecyclerView.Adapter<RowAdapter.VH>() {

    fun setRows(r: List<Row>) {
        rows = r
        notifyDataSetChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.title)
        val desc: TextView = view.findViewById(R.id.desc)
        val value: TextView = view.findViewById(R.id.value)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_setting, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val row = rows[position]
        holder.title.text = row.title
        holder.desc.text = row.desc ?: ""
        holder.desc.visibility = if (row.desc.isNullOrEmpty()) View.GONE else View.VISIBLE
        val v = row.value()
        holder.value.text = if (row.step != null) "\u2039   $v   \u203A" else v

        holder.itemView.setOnClickListener {
            row.onClick()
            notifyItemChanged(holder.bindingAdapterPosition)
        }
        // left / right change the value on rows that support it
        holder.itemView.setOnKeyListener { _, keyCode, ev ->
            val step = row.step
            if (step != null && ev.action == KeyEvent.ACTION_DOWN &&
                (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)
            ) {
                step(if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) -1 else 1)
                notifyItemChanged(holder.bindingAdapterPosition)
                true
            } else {
                false
            }
        }
    }

    override fun getItemCount() = rows.size
}
