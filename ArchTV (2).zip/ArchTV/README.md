# Arch TV
A simple, ad-free Android TV launcher. No AI, no tracking, no recommendations row.
- Liquid-glass panels floating over a photo slideshow (scenic, space, or your own photos)
- Add your own photos from a phone or laptop on the same Wi-Fi
- Clock, date and weather (nearest city found from your IP; Open-Meteo)
- Continue playing row from the apps' own "Play next" lists, with messy titles auto-fixed
- Focus a card and its picture and details fill the screen
- Two-pane settings, with left/right to change values
- Optional Home button override via an Accessibility service
