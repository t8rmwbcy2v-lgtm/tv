package com.arch.tv

import android.animation.ValueAnimator
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import java.lang.ref.WeakReference
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * Keeps a small, heavily blurred copy of whatever picture is full-screen right now.
 * Glass panels draw the matching piece of it behind themselves, which is what makes
 * them look like frosted glass sitting on top of the photo.
 */
object GlassBackdrop {
    const val DS = 8 // one blurred pixel covers 8 screen pixels

    @Volatile
    var strength = 1f

    var cur: Bitmap? = null
        private set
    var prev: Bitmap? = null
        private set
    var fade = 1f
        private set

    private var base: Bitmap? = null
    private var over: Bitmap? = null
    private var winW = 1920
    private var winH = 1080

    @Volatile
    private var version = 0
    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val views = ArrayList<WeakReference<GlassLayout>>()
    private var anim: ValueAnimator? = null

    fun register(v: GlassLayout) {
        views.add(WeakReference(v))
    }

    fun unregister(v: GlassLayout) {
        views.removeAll { it.get() == null || it.get() === v }
    }

    fun invalidateAll() {
        val it = views.iterator()
        while (it.hasNext()) {
            val v = it.next().get()
            if (v == null) it.remove() else v.invalidate()
        }
    }

    fun updateStrength(s: Float) {
        strength = s
        invalidateAll()
    }

    fun setWindow(w: Int, h: Int) {
        if (w > 0 && h > 0 && (w != winW || h != winH)) {
            winW = w
            winH = h
            refresh()
        }
    }

    /** The wallpaper behind the home screen (or the settings screen). */
    fun setBase(src: Bitmap?) {
        base = src
        refresh()
    }

    /** A picture that temporarily covers the wallpaper (the focused Continue playing card). */
    fun setOver(src: Bitmap?) {
        if (over == null && src == null) return
        over = src
        refresh()
    }

    private fun refresh() {
        val src = over ?: base
        val gen = ++version
        if (src == null) {
            main.post { if (gen == version) applyBlur(null) }
            return
        }
        val w = winW
        val h = winH
        exec.execute {
            val b = try {
                makeBlur(src, w, h)
            } catch (t: Throwable) {
                null
            }
            main.post { if (gen == version) applyBlur(b) }
        }
    }

    private fun applyBlur(b: Bitmap?) {
        prev = cur
        cur = b
        anim?.cancel()
        if (prev == null || b == null) {
            prev = null
            fade = 1f
            invalidateAll()
            return
        }
        fade = 0f
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 500
            addUpdateListener {
                fade = it.animatedValue as Float
                if (fade >= 1f) prev = null
                invalidateAll()
            }
            start()
        }
    }

    // ---------- blur ----------

    private fun makeBlur(src: Bitmap, w: Int, h: Int): Bitmap {
        val bw = (w + DS - 1) / DS
        val bh = (h + DS - 1) / DS
        val out = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        // same "fill the screen" scaling the wallpaper uses, just much smaller
        val s = max(bw.toFloat() / src.width, bh.toFloat() / src.height)
        val m = Matrix()
        m.setScale(s, s)
        m.postTranslate((bw - src.width * s) / 2f, (bh - src.height * s) / 2f)
        c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))

        val px = IntArray(bw * bh)
        out.getPixels(px, 0, bw, 0, 0, bw, bh)
        blur(px, bw, bh, 4)
        out.setPixels(px, 0, bw, 0, 0, bw, bh)
        return out
    }

    /** Three box-blur passes in each direction, which is close to a smooth gaussian blur. */
    private fun blur(px: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(px.size)
        repeat(3) {
            pass(px, tmp, w, h, r, true)
            pass(tmp, px, w, h, r, false)
        }
    }

    private fun clamp(v: Int, lo: Int, hi: Int) = if (v < lo) lo else if (v > hi) hi else v

    private fun pass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horiz: Boolean) {
        val len = if (horiz) w else h
        val lines = if (horiz) h else w
        val stride = if (horiz) 1 else w
        val n = 2 * r + 1
        for (line in 0 until lines) {
            val base = if (horiz) line * w else line
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val c = src[base + clamp(i, 0, len - 1) * stride]
                sr += (c shr 16) and 0xFF
                sg += (c shr 8) and 0xFF
                sb += c and 0xFF
            }
            for (i in 0 until len) {
                dst[base + i * stride] = (0xFF shl 24) or ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
                val rem = src[base + clamp(i - r, 0, len - 1) * stride]
                val add = src[base + clamp(i + r + 1, 0, len - 1) * stride]
                sr += ((add shr 16) and 0xFF) - ((rem shr 16) and 0xFF)
                sg += ((add shr 8) and 0xFF) - ((rem shr 8) and 0xFF)
                sb += (add and 0xFF) - (rem and 0xFF)
            }
        }
    }
}
